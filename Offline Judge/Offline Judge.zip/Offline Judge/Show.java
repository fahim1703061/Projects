import java.util.Scanner;


public class Show{

	public static void main(String []args){
	
	System.out.println("sys");
	Scanner scanner = new Scanner(System.in);
	String readString = scanner.nextLine();
	//String string = rea
	System.out.println(readString+"nn");

	}
}