#include <iostream>
#include <cstdio>

using namespace std;


int main()
{
    int A,B,X;
   // cout<<"hi"<<endl;
    scanf("%d%d",&A,&B);
    X=A-B;
    printf("%d\n",X);
    return 0;
}

