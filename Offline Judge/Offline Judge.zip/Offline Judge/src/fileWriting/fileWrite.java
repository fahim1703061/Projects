package fileWriting;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.imageio.IIOException;

public class fileWrite {
	
	private String str;
	private String fname;
	private FileWriter fw;
	private PrintWriter pw;
	
	
	public fileWrite(String str, String fname) {
		
		this.str = str;
		this.fname = fname;
		
	}
	public void write() {
		try {
			fw = new FileWriter(fname);
			//fW.write("file writing\nnew");
			pw = new PrintWriter(fw);
			pw.println(str);
			pw.close();
			
//			FileWriter fileW2 = new FileWriter("c:/temp/samplefile.txt", true); //Set true for append mode
//		    PrintWriter printWriter = new PrintWriter(fileW2);
//		    //PrintWriter printWriter = new PrintWriter(fW2);
//			//fW.close();
//			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			
			//System.out.println("file write\nnew");
		}
	}
		
	public void append() {
		try {
			fw = new FileWriter(fname,true);
			//fW.write("file writing\nnew");
			pw = new PrintWriter(fw);
			pw.println(str);
			pw.close();
			
//			FileWriter fileW2 = new FileWriter("c:/temp/samplefile.txt", true); //Set true for append mode
//		    PrintWriter printWriter = new PrintWriter(fileW2);
//		    //PrintWriter printWriter = new PrintWriter(fW2);
//			//fW.close();
//			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			
			System.out.println("file append\nnew");
		}
		
	}
	
	
	public void append(String temp) {
		str=temp;
		try {
			fw = new FileWriter(fname,true);
			//fW.write("file writing\nnew");
			pw = new PrintWriter(fw);
			pw.println(str);
			pw.close();
			
//			FileWriter fileW2 = new FileWriter("c:/temp/samplefile.txt", true); //Set true for append mode
//		    PrintWriter printWriter = new PrintWriter(fileW2);
//		    //PrintWriter printWriter = new PrintWriter(fW2);
//			//fW.close();
//			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			
			System.out.println("file append\nnew");
		}
		
	}

}
