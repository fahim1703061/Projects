package fileWriting;

import java.awt.Label;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
//import jx

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

public class xlWorking {

	public void exportTable(JTable table, File file) throws IOException {
		TableModel model = table.getModel();
		FileWriter out = new FileWriter(file);
		for (int i = 0; i < model.getColumnCount(); i++) {
			out.write(model.getColumnName(i) + "\t");
		}
		out.write("\n");

		for (int i = 0; i < model.getRowCount(); i++) {
			for (int j = 0; j < model.getColumnCount(); j++) {
				out.write(model.getValueAt(i, j).toString() + "\t");
			}
			out.write("\n");
		}

		out.close();
		System.out.println("write out to: " + file);
	}
	
	//public DefaultTableModel importTable(File f) throws Exception, IOException {
	//public JTable importTable(File f) throws Exception, IOException {
	public TableModel importTable(File f) throws Exception, IOException {
		 //File f=new File("f5.xls"); 
         
		JTable table1 = new JTable();
		 //Workbook wb1=Workbook.get  
		 Workbook wb;
		 wb=Workbook.getWorkbook(f);
		 try {
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("pp");
			e.printStackTrace();
		}
	      Sheet s=wb.getSheet(0); 
	      int row=s.getRows(); 
	      int col=s.getColumns();
	      String []colmn = new String[col];
	      String [][]rw = new String[row-1][col];
	      for (int i = 0; i <1; i++) { 
	          for (int j = 0; j <col; j++) { 
	              Cell c=s.getCell(j, i); 
	              colmn[j]=c.getContents();
	              System.out.print(c.getContents()+"\t\t");                         
	          } 
	          System.out.println(""); 
	          
	      }
	      
	      for (int i = 1; i <row; i++) { 
	          for (int j = 0; j <col; j++) { 
	              Cell c=s.getCell(j, i); 
	              rw[i-1][j]=c.getContents();
	              System.out.print(c.getContents()+"\t\t");                         
	          } 
	          System.out.println(""); 
	          
	      }
	      JTable table = new JTable(rw,colmn);
//	      Object rowObject[][]=rw;
//	      Object colmnObject[]=colmn;
	      TableModel tModel = new DefaultTableModel(rw, colmn) {

//			@Override
//			public void addRow(Object[] arg0) {
//				// TODO Auto-generated method stub
//				  addRow(arg0);
//			}

			@Override
			public boolean isCellEditable(int row, int column) {
				// TODO Auto-generated method stub
				return false;
			}
	    	 
	      };
	      //return new DefaultTableModel(rw,colmn);
	      
	      //return table;
	      return tModel;
	}
	
//	private static void writeExcel() throws WriteException, IOException {
//		String filePath = "D:\\employee.xls";
//		WritableWorkbook workBook = null;
//		try {
//			//initialize workbook
//			workBook = Workbook.createWorkbook(new File(filePath));
//			//create sheet with name as Employee and index 0
//			WritableSheet sheet = workBook.createSheet("Employee", 0);
//			// create font style for header cells
//			WritableFont headerCellFont = new WritableFont(WritableFont.ARIAL, 14,
//					WritableFont.BOLD, true);
//			//create format for header cells
//			WritableCellFormat headerCellFormat = new WritableCellFormat(
//					headerCellFont);
//			// create header cells
//			Label headerCell1 = new Label();
//			Label headerCell2 = new Label(1, 0, "Department", headerCellFormat);
//			Label headerCell3 = new Label(2, 0, "Workplace", headerCellFormat);
//			// add header cells to sheet
//			sheet.addCell(headerCell1);
//			sheet.addCell(headerCell2);
//			sheet.addCell(headerCell3);
//			// create cell contents for Employee 1
//			Label employee1Id = new Label(0, 1, "123");
//			Label employee1Department = new Label(1, 1, "Customer Support");
//			Label employee1Workplace = new Label(2, 1, "Bangalore, India");
//			// add cells to sheet
//			sheet.addCell(employee1Id);
//			sheet.addCell(employee1Department);
//			sheet.addCell(employee1Workplace);
//			// create cells content for Employee 2
//			Label employee2Id = new Label(0, 2, "456");
//			Label employee2Department = new Label(1, 2, "Quality Assurance");
//			Label employee2Workplace = new Label(2, 2, "California, USA");
//			// add cells to sheet
//			sheet.addCell(employee2Id);
//			sheet.addCell(employee2Department);
//			sheet.addCell(employee2Workplace);
//			//for setting width of columns
//			sheet.setColumnView(0, 15);
//			sheet.setColumnView(1, 20);
//			sheet.setColumnView(2, 15);
//			//write workbook
//			jxl.write.Label
//			workBook.write();
//		} catch (IOException e) {
//			e.printStackTrace();
//		} catch (RowsExceededException e) {
//			e.printStackTrace();
//		} catch (WriteException e) {
//			e.printStackTrace();
//		} finally {
//			//close workbook
//			workBook.close();
//		}
	
	
	
	public void writeExcel1() throws WriteException, IOException {
		String filePath = "employee.xls";
		WritableWorkbook workBook = null;
		try {
			//initialize workbook
			workBook = Workbook.createWorkbook(new File(filePath));
			//create sheet with name as Employee and index 0
			WritableSheet sheet = workBook.createSheet("Employee", 0);
			// create font style for header cells
			WritableFont headerCellFont = new WritableFont(WritableFont.ARIAL, 12,
					WritableFont.BOLD, true);
			//create format for header cells
			WritableCellFormat headerCellFormat = new WritableCellFormat(
					headerCellFont);
			// create header cells
			jxl.write.Label headerCell1 = new jxl.write.Label(0, 0, "Employee ID", headerCellFormat);
			jxl.write.Label headerCell2 = new jxl.write.Label(1, 0, "Department", headerCellFormat);
			jxl.write.Label headerCell3 = new jxl.write.Label(2, 0, "Workplace", headerCellFormat);
			// add header cells to sheet
			sheet.addCell(headerCell1);
			sheet.addCell(headerCell2);
			sheet.addCell(headerCell3);
			// create cell contents for Employee 1
			jxl.write.Label employee1Id = new jxl.write.Label(0, 1, "123");
			jxl.write.Label employee1Department = new jxl.write.Label(1, 1, "Customer Support");
			jxl.write.Label employee1Workplace = new jxl.write.Label(2, 1, "Bangalore, India");
			// add cells to sheet
			sheet.addCell(employee1Id);
			sheet.addCell(employee1Department);
			sheet.addCell(employee1Workplace);
			// create cells content for Employee 2
			jxl.write.Label employee2Id = new jxl.write.Label(0, 2, "456");
			jxl.write.Label employee2Department = new jxl.write.Label(1, 2, "Quality Assurance");
			jxl.write.Label employee2Workplace = new jxl.write.Label(2, 2, "California, USA");
			// add cells to sheet
			sheet.addCell(employee2Id);
			sheet.addCell(employee2Department);
			sheet.addCell(employee2Workplace);
			//for setting width of columns
			sheet.setColumnView(0, 15);
			sheet.setColumnView(1, 20);
			sheet.setColumnView(2, 15);
			
			
			//write workbook
			workBook.write();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (RowsExceededException e) {
			e.printStackTrace();
		} catch (WriteException e) {
			e.printStackTrace();
		} finally {
			//close workbook
			workBook.close();
		}
	}
	
	
	public void writeExcel(JTable table, File file) throws WriteException, IOException {
		//String filePath = "employee.xls";
		WritableWorkbook workBook = null;
		try {
			TableModel model = table.getModel();
			//initialize workbook
			//workBook = Workbook.createWorkbook(new File(filePath));
			workBook = Workbook.createWorkbook(file);
			//create sheet with name as Employee and index 0
			WritableSheet sheet = workBook.createSheet(" ", 0);
			// create font style for header cells
//			WritableFont headerCellFont = new WritableFont(WritableFont.ARIAL, 14,
//					WritableFont.BOLD, true);
			WritableFont headerCellFont = new WritableFont(WritableFont.ARIAL, 12,
					WritableFont.BOLD, true);
			//create format for header cells
			WritableCellFormat headerCellFormat = new WritableCellFormat(
					headerCellFont);
			// create header cells
//			jxl.write.Label headerCell1 = new jxl.write.Label(0, 0, "Employee ID", headerCellFormat);
//			jxl.write.Label headerCell2 = new jxl.write.Label(1, 0, "Department", headerCellFormat);
//			jxl.write.Label headerCell3 = new jxl.write.Label(2, 0, "Workplace", headerCellFormat);
			// add header cells to sheet
//			sheet.addCell(headerCell1);
//			sheet.addCell(headerCell2);
//			sheet.addCell(headerCell3);
			for (int i = 0; i < model.getColumnCount(); i++) {
				//out.write(model.getColumnName(i) + "\t");
				sheet.addCell(new jxl.write.Label(i,0,model.getColumnName(i),headerCellFormat));
			}
			// create cell contents for Employee 1
//			jxl.write.Label employee1Id = new jxl.write.Label(0, 1, "123");
//			jxl.write.Label employee1Department = new jxl.write.Label(1, 1, "Customer Support");
//			jxl.write.Label employee1Workplace = new jxl.write.Label(2, 1, "Bangalore, India");
			// add cells to sheet
//			sheet.addCell(employee1Id);
//			sheet.addCell(employee1Department);
//			sheet.addCell(employee1Workplace);
			// create cells content for Employee 2
			
			// add cells to sheet
//			sheet.addCell(employee2Id);
//			sheet.addCell(employee2Department);
//			sheet.addCell(employee2Workplace);
			//for setting width of columns
			sheet.setColumnView(0, 15);
			sheet.setColumnView(1, 20);
			sheet.setColumnView(2, 15);
			
			for (int i = 0; i < model.getRowCount(); i++) {
				for (int j = 0; j < model.getColumnCount(); j++) {
					sheet.addCell(new jxl.write.Label(j,i+1,model.getValueAt(i, j).toString()));
				}
				//out.write("\n");
			}
			
			
			//write workbook
			workBook.write();
		} catch (IOException e) {
			System.out.println("lllllllllllllllll");
			e.printStackTrace();
		} catch (RowsExceededException e) {
			e.printStackTrace();
			System.out.println("lllllllllllllllll");
		} catch (WriteException e) {
			System.out.println("lllllllllllllllll");
			e.printStackTrace();
		} finally {
			//close workbook
			workBook.close();
		}
	}
	
	
	public void writeExcelappend(JTable table, File file,String value[]) throws WriteException, IOException {
		//String filePath = "employee.xls";
		WritableWorkbook workBook = null;
		try {
			TableModel model = table.getModel();
			//initialize workbook
			workBook = Workbook.createWorkbook(file);
			//create sheet with name as Employee and index 0
			WritableSheet sheet = workBook.createSheet(" ", 0);
			// create font style for header cells
//			WritableFont headerCellFont = new WritableFont(WritableFont.ARIAL, 14,
//					WritableFont.BOLD, true);
			WritableFont headerCellFont = new WritableFont(WritableFont.ARIAL, 12,
					WritableFont.BOLD, true);
			//create format for header cells
			WritableCellFormat headerCellFormat = new WritableCellFormat(
					headerCellFont);
			// create header cells
//			jxl.write.Label headerCell1 = new jxl.write.Label(0, 0, "Employee ID", headerCellFormat);
//			jxl.write.Label headerCell2 = new jxl.write.Label(1, 0, "Department", headerCellFormat);
//			jxl.write.Label headerCell3 = new jxl.write.Label(2, 0, "Workplace", headerCellFormat);
			// add header cells to sheet
//			sheet.addCell(headerCell1);
//			sheet.addCell(headerCell2);
//			sheet.addCell(headerCell3);
			for (int i = 0; i < model.getColumnCount(); i++) {
				//out.write(model.getColumnName(i) + "\t");
				sheet.addCell(new jxl.write.Label(i,0,model.getColumnName(i),headerCellFormat));
			}
			// create cell contents for Employee 1
//			jxl.write.Label employee1Id = new jxl.write.Label(0, 1, "123");
//			jxl.write.Label employee1Department = new jxl.write.Label(1, 1, "Customer Support");
//			jxl.write.Label employee1Workplace = new jxl.write.Label(2, 1, "Bangalore, India");
			// add cells to sheet
//			sheet.addCell(employee1Id);
//			sheet.addCell(employee1Department);
//			sheet.addCell(employee1Workplace);
			// create cells content for Employee 2
			
			// add cells to sheet
//			sheet.addCell(employee2Id);
//			sheet.addCell(employee2Department);
//			sheet.addCell(employee2Workplace);
			//for setting width of columns
			sheet.setColumnView(0, 15);
			sheet.setColumnView(1, 20);
			sheet.setColumnView(2, 15);
			
			for (int i = 0; i < model.getRowCount(); i++) {
				for (int j = 0; j < model.getColumnCount(); j++) {
					sheet.addCell(new jxl.write.Label(j,i+1,model.getValueAt(i, j).toString()));
				}
				//out.write("\n");
			}
			for (int j = 0; j < model.getColumnCount(); j++) {
				sheet.addCell(new jxl.write.Label(j,model.getRowCount()+1,value[j]));
			}
			
			
			//write workbook
			workBook.write();
		} catch (IOException e) {
			System.out.println("cslling");
			e.printStackTrace();
		} catch (RowsExceededException e) {
			e.printStackTrace();
		} catch (WriteException e) {
			System.out.println("cslling4");
			e.printStackTrace();
		} finally {
			//close workbook
			workBook.close();
		}
	}
	}
