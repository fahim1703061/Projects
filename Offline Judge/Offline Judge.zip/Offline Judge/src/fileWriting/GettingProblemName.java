package fileWriting;

import javax.swing.JTable;

public class GettingProblemName {

	public String getProblemName(JTable table,String probid) {
		String tempString= new String();
		for(int i=0;i<table.getModel().getRowCount();i++) {
			tempString=table.getModel().getValueAt(i, 0).toString();
			if(tempString.equals(probid)) {
				return table.getModel().getValueAt(i, 1).toString();
			}
		}
		return "";
	}
}
