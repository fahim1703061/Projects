#include <stdio.h>

int main()
{
    printf("all is well");
    return 0;

}