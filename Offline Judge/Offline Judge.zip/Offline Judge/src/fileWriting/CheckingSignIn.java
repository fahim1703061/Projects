package fileWriting;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class CheckingSignIn {


	private String fname,username,password;
	private FileReader fr;
	
	
	public CheckingSignIn(String username, String password) {
		//super();
		this.username = username;
		this.password = password;
	}
	
	public CheckingSignIn(String fname, String username, String password) {
		//super();
		this.fname = fname;
		this.username = username;
		//System.out.println(username);
		this.password = password;
	}
	public boolean ismatch() throws IOException {
		//System.out.println("called");
		try {
			fr = new FileReader(fname);
			BufferedReader br = new BufferedReader(fr);
			String lineString;
			while ((lineString = br.readLine())!=null) {
				//System.out.println(lineString);
				if(username.equals(lineString)) {
					//System.out.println(lineString);
					return check();
					
				}
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}
	
	public boolean check() throws IOException {
		try {
			fr = new FileReader("data/account/"+username+".txt");
			BufferedReader br = new BufferedReader(fr);
			String lineString;
			while ((lineString = br.readLine())!=null) {
				//System.out.println(password);
				if(password.equals(lineString)) {
					return true;
				}
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
}
