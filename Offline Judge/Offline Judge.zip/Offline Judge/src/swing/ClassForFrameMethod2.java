package swing;

import java.awt.Graphics;
import java.awt.HeadlessException;
import java.awt.Image;
import java.awt.Panel;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class ClassForFrameMethod2 extends JPanel {
	
	
private Image img;

	public ClassForFrameMethod2() throws HeadlessException {
		img = Toolkit.getDefaultToolkit().getImage("fahim.jpg");
		//super();
		
		}
		public void paintComponent(Graphics g) {
			super.paintComponent(g);
			g.drawImage(img, 0, 0, this);
		}
		
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//-----------main frame cration---------------
		
				//ClassForFrameMethod2 frame = new ClassForFrameMethod2();
				JFrame frame = new JFrame();
				frame.setVisible(true);
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				//frame.setSize(1000,600);
				//frame.setLocationRelativeTo(null);
				//frame.setLocation(200,50);
				frame.setBounds(200, 80, 1000, 600);
				frame.setTitle("Onsite Judge Developed By @Fahim61");
				frame.getContentPane().add(new ClassForFrameMethod2());
				
	}

}
