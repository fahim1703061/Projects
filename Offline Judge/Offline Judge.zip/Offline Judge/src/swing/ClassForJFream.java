package swing;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JComponent;
import javax.swing.JFrame;

//import swing.labelDemo.BackgroungImg;

public class ClassForJFream {
	

	public static void main(String[] args) {
		class BackgroungImg extends JComponent{
			
			private Image img;
			
			public BackgroungImg(Image img) {
				//super();
				this.img = img;
			}
			
			@Override
			protected void paintComponent(Graphics g) {
				// TODO Auto-generated method stub
				super.paintComponent(g);
				g.drawImage(img, 0, 0, this);
			}
		}
		// TODO Auto-generated method stub
		
		//-----------main frame cration---------------
		
		JFrame frame = new JFrame();
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//frame.setSize(1000,600);
		//frame.setLocationRelativeTo(null);
		//frame.setLocation(200,50);
		frame.setBounds(200, 80, 1000, 600);
		frame.setTitle("Onsite Judge Developed By @Fahim61");
		
		File file = new File("src/swing/fahim.jpg");
		BufferedImage image;
		try {
			image = ImageIO.read(file);
			frame.setContentPane(new BackgroungImg(image));
			
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

	}

}
