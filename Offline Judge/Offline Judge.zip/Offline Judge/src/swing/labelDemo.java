package swing;

import fileWriting.CheckingSignIn;
import fileWriting.GettingProblemName;
import fileWriting.fileWrite;
import fileWriting.xlWorking;
import filereading.pdfRead;
import jxl.read.biff.BiffException;
import jxl.write.WriteException;
import languagecheck.CChecking;
import languagecheck.CppChecking;
import languagecheck.JavaChecking;

import java.awt.Color;

import java.awt.Container;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.HeadlessException;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.chrono.JapaneseChronology;
import java.util.Random;
import java.util.concurrent.CyclicBarrier;

import javax.imageio.IIOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import org.omg.CORBA.PRIVATE_MEMBER;

public class labelDemo extends JFrame {
	
	
	private ImageIcon icon;
	private Container c;
	private JLabel userLabel,passLabel,headLabel,codeLabel,proglangLabel,probnoLabel,signoutLabel;
	private Font f;
	private ImageIcon img;
	private JTextField usernameField,probnoField,tempTextField,addproblemidField;
	private JPasswordField passwordField;
	private ActionOnText action;
	private JButton signInButton,signoutButton;
	private JButton signupButton,submitButton,addProblemButton;
	private Cursor cursor;
	private JTextArea textArea,inpuTextArea,outpuTextArea;
	private JScrollPane scroll,scrollforprbtble,scrollforsubtble;
	private JComboBox cb;
	private String [] progLan = {"C","C++","Java","Python"};
	private String usertemp;
	private JTabbedPane tb;
	private JPanel problemPanel,submissionPanel,contestPanel,helpPanel,submitPanel,signinPanel,addproblemPanel;
	private JTable problemsetTable,submissionTable;
	//private DefaultTableModel modelsubmission,modelproblem;
	private xlWorking excel;
	private TableModel modelsubmission,modelproblem;
	
	
	private String colforproblemset []= {"Serial No.","Problem ID","Problem Name","Difficulty"};
	private String rowforproblemset[][]= {
			
											{"1","Codeforces-4A","Watermelon","Easy"},
											{"2","Codeforces-4A","Watermelon","Easy"},
											{"3","Codeforces-4A","Watermelon","Easy"},
			
			
										 };
	
	private String colforsubmission []= {"Serial No.","Username","Problem ID","Problem Name","Verdict"};
	private String rowforsubmission[][]= {
			
											{"1","user01","Codeforces-4A","Watermelon","Accepted"},
											{"2","user02","Codeforces-4A","Watermelon","Wrong Anser"},
											{"3","user03","Codeforces-4A","Watermelon","Time Limit Exceeded"},
			
			
										 };
	
	
	//------------------contructor----------
	
	class BackgroungImg extends JComponent{

		private Image img;
		
		public BackgroungImg(Image img) {
			super();
			this.img = img;
		}

		@Override
		protected void paintComponent(Graphics g) {
			// TODO Auto-generated method stub
			super.paintComponent(g);
			
			g.drawImage(img, 0, 0, this);
		}
	}
	
	
//	class BackgroungImg extends JPanel{
//
//		private Image img;
//		
//		public BackgroungImg(Image img) {
//			//super();
//			this.img =Toolkit.getDefaultToolkit().getImage("src/swing/fahim.jpg");
//		}
//
//		@Override
//		protected void paintComponent(Graphics g) {
//			// TODO Auto-generated method stub
//			super.printComponent(g);
//			g.drawImage(img, 0, 0, this);
//		}
//	}
	
	
	
	public labelDemo() {
		seticon();
		useContainer();
		
		//signout("tt",true);
	}
	
	
	public void useContainer() {
		// TODO Auto-generated method stub
		
		File file = new File("download1-5.jpg");
		Image image;
		Image img1;
		try {
			img1 = Toolkit.getDefaultToolkit().getImage("download1-5.jpg");
			image = ImageIO.read(file);
			//bck.setVisible(true);
			//this.setContentPane(bck);
			//this.setContentPane(new BackgroungImg(img1));
			BackgroungImg bck = new BackgroungImg(image);
			//bck.setBounds(0, 0, 1000, 600);
			this.setContentPane(bck);
			
			//this.getContentPane().add(bck);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		c=getContentPane();
		c.setLayout(null);
		//c.add(bck);
		//c.setBackground(Color.DARK_GRAY);
		f = new Font("Arial",Font.BOLD,24);
		
		headLabel = new JLabel();
		headLabel.setText("Onsite Judge");
		headLabel.setBounds(400,10,200,30);
		headLabel.setForeground(Color.WHITE);
		//userLabel.setBackground(Color.PINK);
		headLabel.setFont(f);
		
		c.add(headLabel);
		//tb.setVisible(false);
		
		signinPanel = new JPanel();
		signinPanel.setBounds(390,160,150,224);
		signinPanel.setLayout(null);
		signinPanel.setBackground(Color.DARK_GRAY);
		c.add(signinPanel);
		
		//addproblemPanel
		
		f = new Font("Arial",Font.BOLD,16);
		
		userLabel = new JLabel("Enter username:");
		userLabel.setBounds(0,0,150,30);
		userLabel.setFont(f);
		userLabel.setForeground(Color.black);
		userLabel.setOpaque(true);
		userLabel.setBackground(Color.CYAN);
		
		//c.add(userLabel);
		signinPanel.add(userLabel);
		
		passLabel = new JLabel("Enter password:");
		passLabel.setBounds(0,70,150,30);
		passLabel.setFont(f);
		passLabel.setForeground(Color.black);
		passLabel.setOpaque(true);
		passLabel.setBackground(Color.CYAN);
		passLabel.setToolTipText("password must be mixed with character and number");
		//System.out.println(passLabel.getText());
		
		//c.add(passLabel);
		signinPanel.add(passLabel);
		
		
		//-----------adding labelimage--------
		
		img = new ImageIcon(getClass().getResource("oj-label.png"));
		JLabel imgLabel = new JLabel(img);
		imgLabel.setBounds(370,10,img.getIconWidth(),img.getIconHeight());
		c.add(imgLabel);
		
		
		//--------adding text field--------
		
		usernameField = new JTextField();
		usernameField.setBounds(0,35,150,30);
		f = new Font("Arial",Font.BOLD,16);
		usernameField.setFont(f);
		//c.add(usernameField);
		signinPanel.add(usernameField);
		
		action = new ActionOnText(); 
		usernameField.addActionListener(action);


		passwordField = new JPasswordField();
		passwordField.setBounds(0,80+passLabel.getHeight(),passLabel.getWidth(),userLabel.getHeight());
		f = new Font("Arial",Font.BOLD,20);
		passwordField.setFont(f);
		//c.add(passwordField);
		signinPanel.add(passwordField);
		
		passwordField.addActionListener(action);
		
		//------------label head and proglanglabal for text area----------
		
		codeLabel = new JLabel("Submit Code:");
		f = new Font("Arial",Font.BOLD,12);
		codeLabel.setForeground(Color.BLACK);
		codeLabel.setBounds(110,0,120,40);
		codeLabel.setFont(f);
		//c.add(codeLabel);
		codeLabel.setVisible(true);
		
		proglangLabel = new JLabel("Language:");
		proglangLabel.setForeground(Color.BLACK);
		proglangLabel.setBounds(3,30,70,30);
		proglangLabel.setFont(f);
		//c.add(proglangLabel);
		//submitPanel.add(proglangLabel);
//		cursor = new Cursor(Cursor.HAND_CURSOR);
//		proglangLabel.setCursor(cursor);
		//proglangLabel.setVisible(false);
		
		
		
		//---------------text area for taking code----------
		
		textArea = new JTextArea();
		f = new Font("Arial",Font.PLAIN,16);
		textArea.setFont(f);
		scroll = new JScrollPane(textArea,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scroll.setBounds(110,38,650,440);
		scroll.setBackground(Color.WHITE);
		//c.add(scroll);
		//scroll.setVisible(false);
		

		//--------------adding sign in and sign up Button---------
		
		cursor = new Cursor(Cursor.HAND_CURSOR);
		
		signInButton = new JButton("Sign In");
		signInButton.setBounds(0,150,passwordField.getWidth(),passwordField.getHeight());
		signInButton.setCursor(cursor);
		//f = new Font("Arial",Font.BOLD,16);
		//signInButton.setFont(f);
		//c.add(signInButton);
		signinPanel.add(signInButton);
		
		signInButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				//c.add(scroll);
				CheckingSignIn checkingSignIn = new CheckingSignIn("data/useridlist/usernamelist.txt",usernameField.getText(), String.valueOf(passwordField.getPassword()));
				try {
					if(checkingSignIn.ismatch() == false) {
					//if(false) {
						JOptionPane.showMessageDialog(null, "Enter correct username and password");
						
						
					}
					else {
//					textArea = new JTextArea();
//					scroll = new JScrollPane(textArea,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
//					scroll.setBounds(200,100,300,450);
						//c.add(scroll);
						JOptionPane.showMessageDialog(null, "Successfully signed in");
						signout(usernameField.getText(), true);
						usertemp=usernameField.getText();
						usernameField.setText("");
						passwordField.setText("");
						signinPanel.setVisible(false);
						tb.setVisible(true);
						
						
					}
				} catch (HeadlessException | IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
//				catch (IOException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
			}
		});
		
		signupButton = new JButton("Sign Up");
		signupButton.setBounds(0,160+signInButton.getHeight(),passwordField.getWidth(),passwordField.getHeight());
		signupButton.setCursor(cursor);
		//f = new Font("Arial",Font.BOLD,16);
		//signupButton.setFont(f);
		//c.add(signupButton);
		signinPanel.add(signupButton);
		SignUpframe signUpframe = new SignUpframe();
	
		signupButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				//c.remove(signupButton);
				//dispose();
				//c.remove(signInButton);
				signUpframe.setVisible(true);
				//signupButton.setEnabled(true);
				//signupButton.setEnabled(true);
//				if(signUpframe.Clos == JFrame.DISPOSE_ON_CLOSE) {
//					c.add(signupButton);
//					System.out.println("ttt");
//				}
				//c.add(signupButton);
				
			}
		});
		
//		if(signUpframe.isSubmitButtonPressed()) {
//			signupButton.setEnabled(true);
//			System.out.println("tt"+signUpframe.isSubmitButtonPressed());
//		}
		//----------------adding submit button--------------
		
		submitButton = new JButton("Submit");
		submitButton.setBounds(3,300,80,40);
		//submitButton.setBounds(100,100,50,50);
		submitButton.setCursor(cursor);
		//f = new Font("Arial",Font.BOLD,16);
		//signupButton.setFont(f);
		//c.add(submitButton);
		//submitButton.setVisible(false);
	
		submitButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				if (cb.getSelectedItem().toString().toLowerCase().equals("java")) {
					//String codefileString = "data/submitted code/"+"Problem4A"+"."+"java";
					String codefileString = probnoField.getText() + "." + "java";
					FileWriter codeWriter;
					try {
						codeWriter = new FileWriter(codefileString);
						textArea.write(codeWriter);
						textArea.setText("");
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					JavaChecking javaChecking = new JavaChecking(probnoField.getText() + "." + "java", "data\\problem\\" +probnoField.getText()+"\\"+probnoField.getText());
					String resultJava = javaChecking.compilejava();
					System.out.println(resultJava);
					System.out.println(cb.getSelectedItem().toString());
					String serial_value = new String();
					for (int i = 0; i < submissionTable.getModel().getRowCount(); i++) {
						serial_value = submissionTable.getModel().getValueAt(i, 0).toString();

					}
					System.out.println(serial_value);
					int k = Integer.parseInt(serial_value);
					k++;
					serial_value = String.valueOf(k);
					System.out.println(String.valueOf(k));
					//String[] value = new String[5];
					Object [] value = new Object[5];
					value[0] = serial_value;
					value[1] = usertemp;
					value[2] = probnoField.getText();
					value[3] = new GettingProblemName().getProblemName(problemsetTable, probnoField.getText());
					value[4] = resultJava;
					//modelsubmission.
					((DefaultTableModel) modelsubmission).addRow(value);
					try {
						new xlWorking().writeExcel(submissionTable, new File("data\\table\\subtable.xls"));
					} catch (WriteException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} 
				}
				else if (cb.getSelectedItem().toString().toLowerCase().equals("c")) {
					//String codefileString = "data/submitted code/"+"Problem4A"+"."+"java";
					String codefileString = probnoField.getText() + "." + "c";
					FileWriter codeWriter;
					try {
						codeWriter = new FileWriter(codefileString);
						textArea.write(codeWriter);
						textArea.setText("");
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					CChecking cChecking = new CChecking(probnoField.getText() + "." + "c", "data\\problem\\" +probnoField.getText()+"\\"+probnoField.getText());
					String resultJava = cChecking.compilec();
					System.out.println(resultJava);
					System.out.println(cb.getSelectedItem().toString());
					String serial_value = new String();
					for (int i = 0; i < submissionTable.getModel().getRowCount(); i++) {
						serial_value = submissionTable.getModel().getValueAt(i, 0).toString();

					}
					System.out.println(serial_value);
					int k = Integer.parseInt(serial_value);
					k++;
					serial_value = String.valueOf(k);
					System.out.println(String.valueOf(k));
					//String[] value = new String[5];
					Object [] value = new Object[5];
					value[0] = serial_value;
					value[1] = usertemp;
					value[2] = probnoField.getText();
					value[3] = new GettingProblemName().getProblemName(problemsetTable, probnoField.getText());
					value[4] = resultJava;
					//modelsubmission.
					((DefaultTableModel) modelsubmission).addRow(value);
					try {
						new xlWorking().writeExcel(submissionTable, new File("data\\table\\subtable.xls"));
					} catch (WriteException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} 
				}
				else if (cb.getSelectedItem().toString().toLowerCase().equals("c++")) {
					//String codefileString = "data/submitted code/"+"Problem4A"+"."+"java";
					String codefileString = probnoField.getText() + "." + "cpp";
					FileWriter codeWriter;
					try {
						codeWriter = new FileWriter(codefileString);
						textArea.write(codeWriter);
						textArea.setText("");
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					CppChecking cppChecking = new CppChecking(probnoField.getText() + "." + "cpp", "data\\problem\\" +probnoField.getText()+"\\"+probnoField.getText());
					String resultJava = cppChecking.compilecpp();
					System.out.println(resultJava);
					System.out.println(cb.getSelectedItem().toString());
					String serial_value = new String();
					for (int i = 0; i < submissionTable.getModel().getRowCount(); i++) {
						serial_value = submissionTable.getModel().getValueAt(i, 0).toString();

					}
					System.out.println(serial_value);
					int k = Integer.parseInt(serial_value);
					k++;
					serial_value = String.valueOf(k);
					System.out.println(String.valueOf(k));
					//String[] value = new String[5];
					Object [] value = new Object[5];
					value[0] = serial_value;
					value[1] = usertemp;
					value[2] = probnoField.getText();
					value[3] = new GettingProblemName().getProblemName(problemsetTable, probnoField.getText());
					value[4] = resultJava;
					//modelsubmission.
					((DefaultTableModel) modelsubmission).addRow(value);
					try {
						new xlWorking().writeExcel(submissionTable, new File("data\\table\\subtable.xls"));
					} catch (WriteException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} 
				}
				else {
					JOptionPane.showMessageDialog(null, "Selected language is  not available now");
				}
				textArea.setText("");
				
				JOptionPane.showMessageDialog(null, "Successfully submitted");
			}
		});		

		
		//------------creating cmbobox for proglanguage------------
		
		cb = new JComboBox(progLan);
		cb.setBounds(3,60,80,30);
		//submitPanel.add(cb);
		//c.add(cb);
		//cb.setVisible(false);
		
		
		//------------------creating JtabbedPane-------------------
		
		tb = new JTabbedPane();
		tb.setBounds(1,50,787,507);
		c.add(tb);
		tb.setVisible(false);
		
		problemPanel = new JPanel();
		submitPanel = new JPanel();
		submissionPanel = new JPanel();
		contestPanel = new JPanel();
		helpPanel = new JPanel();
		
		tb.addTab("Problems", problemPanel);
		//tb.addTab("Contest", contestPanel);
		tb.addTab("Submit Code", submitPanel);
		tb.addTab("Submission", submissionPanel);
		tb.addTab("Help", helpPanel);
		
		tb.setBackground(Color.WHITE);
		
		submitPanel.setLayout(null);
		//submitPanel.setBackground(Color.MAGENTA);
		submitPanel.add(scroll);
		submitPanel.add(codeLabel);
		submitPanel.add(proglangLabel);
		submitPanel.add(cb);
		submitPanel.add(submitButton);
		
		
		//--------------creating addproblempanel---------------
		
		addproblemPanel = new JPanel();
		addproblemPanel.setBounds(2,55,787,507);
		c.add(addproblemPanel);
		addproblemPanel.setLayout(null);
		addproblemPanel.setVisible(false);
		
		
		// --------------------probno label-------------
		
		
		probnoLabel = new JLabel("Problem No:");
		probnoLabel.setBounds(3,90,90,40);
		probnoLabel.setForeground(Color.BLACK);
		f = new Font("Arial",Font.BOLD,12);
		probnoLabel.setFont(f);
		submitPanel.add(probnoLabel);
		
		probnoField = new JTextField("Codeforces-4A");
		probnoField.setBounds(3,130,90,30);
		probnoField.setBackground(Color.WHITE);
		f = new Font("Arial",Font.BOLD,12);
		probnoField.setFont(f);
		submitPanel.add(probnoField);
		//submitPanel.add(scroll);
		
		
		//-----------------working on probllem panel------------
		
		problemPanel.setLayout(null);
		
		addproblemTable();
		
		
		//--------------working on submission panal------------
		
		submissionPanel.setLayout(null);
		
		addsubmission();
		//submissionTable = new JTable(rowforsubmission,colforsubmission);
		 //model2 = new DefaultTableModel();
		//submissionTable = new JTable(model2);
//		xlWorking excel1 = new xlWorking();
//		try {
//			submissionTable=excel1.importTable(new File("data\\table\\subtable.xls"));
//			scrollforsubtble = new JScrollPane(submissionTable,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
//			scrollforsubtble.setBounds(90,3,620,465);
//			submissionPanel.add(scrollforsubtble);
//		} catch (IOException e2) {
//			// TODO Auto-generated catch block
//			e2.printStackTrace();
//		} catch (Exception e2) {
//			// TODO Auto-generated catch block
//			e2.printStackTrace();
//		}
		
		
		
		
		//--------------working on help------------
		
		
		tempTextField = new JTextField("email:fahimfaisal7373@gmail.com");
		helpPanel.add(tempTextField);
		
		
		
		//System.out.println("called");
		signoutButton = new JButton("sign out");
		signoutLabel = new JLabel("Hi, ");
		signoutLabel.setBounds(850,10,100,50);
		signoutLabel.setForeground(Color.GREEN);
		c.add(signoutLabel);
		
		signoutButton.setBounds(850,50,100,40);
		c.add(signoutButton);
		
		signoutButton.setVisible(false);
		signoutLabel.setVisible(false);
		
		signoutButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				signout("", false);
			}
		});
//		try {
//			xlWorking exel = new xlWorking();
//			//exel.exportTable(submissionTable, new File("f51.xls"));
//			exel.writeExcel1(submissionTable, new File("f51.xls"));
//			try {
//				submissionTable=exel.importTable(new File("f5.xls"));
//			} catch (Exception e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (WriteException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
	}
	
	public void addsubmission() {
		xlWorking excel1 = new xlWorking();
		System.out.println("cld row");

		try {
			modelsubmission=excel1.importTable(new File("data\\table\\subtable.xls"));
			submissionTable= new JTable(modelsubmission);
			//submissionTable=excel1.importTable(new File("f51.xls"));
			//modelsubmission=excel1.importTable(new File("data\\table\\subtable.xls"));
			//modelsubmission=excel1.importTable(new File("f51.xls"));
			scrollforsubtble = new JScrollPane(submissionTable,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			scrollforsubtble.setBounds(90,3,620,465);
			submissionPanel.add(scrollforsubtble);
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
	}
	
	public void addproblemTable() {
		
		
		try {
			//modelproblem = new xlWorking().importTable(new File("prob.xls"));
			modelproblem = new xlWorking().importTable(new File("data\\table\\probtable.xls"));
			
//			TableModel model = modelproblem::{
//				
//			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		problemsetTable = new JTable(modelproblem);
		//problemsetTable.setEnabled(false);
		
		scrollforprbtble = new JScrollPane(problemsetTable,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollforprbtble.setBounds(90,3,500,465);
		problemPanel.add(scrollforprbtble);
		
		
		addProblemButton = new JButton("Add Problem");
		addProblemButton.setBounds(640,20,120,40);
		problemPanel.add(addProblemButton);
		addProblemButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				addproblem();
			}
		});
		
		
		
		problemsetTable.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mousePressed(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseExited(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseEntered(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseClicked(MouseEvent arg0) {
				// TODO Auto-generated method stub
				if(arg0.getClickCount() == 2) {
					JTable newTable = (JTable)arg0.getSource();
					int rowpt = newTable.getSelectedRow();
					int colomnpt= newTable.getSelectedColumn();
					//jp("row "+rowpt+" colm :"+colomnpt);
					if(colomnpt == 0) {
						try {
							new pdfRead().openPdf("data\\problem\\"+problemsetTable.getValueAt(rowpt, colomnpt).toString()+"\\"+problemsetTable.getValueAt(rowpt, colomnpt).toString()+".pdf");
							System.out.println(problemsetTable.getValueAt(rowpt, colomnpt).toString());
							probnoField.setText(problemsetTable.getValueAt(rowpt, colomnpt).toString());
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
							jp("pdf not avilable");
						}
					}
				}
			}
		});
		
//		try {
//			new xlWorking().writeExcel(problemsetTable, new File("ll6.xls"));
//			System.out.println("hmm");
//		} catch (WriteException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
	}
	
	
	//-----------------------Adding          problem---------------------
	
	public void addproblem() {
		
		
	
		tb.setVisible(false);
		addproblemPanel.setVisible(true);
		JLabel probidlLabel = new JLabel("Problem Id");
		probidlLabel.setBounds(3,20-18,90,40);
		probidlLabel.setForeground(Color.BLACK);
		f = new Font("Arial",Font.BOLD,12);
		probidlLabel.setFont(f);
		addproblemPanel.add(probidlLabel);
		
		JTextField probnoField2 = new JTextField();
		probnoField2.setBounds(3,60-18,90,30);
		probnoField2.setBackground(Color.WHITE);
		f = new Font("Arial",Font.BOLD,12);
		probnoField2.setFont(f);
		addproblemPanel.add(probnoField2);
		
		JLabel problinklLabel = new JLabel("Problem Link");
		problinklLabel.setBounds(120,20-18,90,40);
		problinklLabel.setForeground(Color.BLACK);
		f = new Font("Arial",Font.BOLD,12);
		problinklLabel.setFont(f);
		addproblemPanel.add(problinklLabel);
		
		JTextField problinkField = new JTextField();
		problinkField.setBounds(120,60-18,90,30);
		problinkField.setBackground(Color.WHITE);
		f = new Font("Arial",Font.BOLD,12);
		problinkField.setFont(f);
		addproblemPanel.add(problinkField);
		
		JLabel pnameLabel = new JLabel("Problem name");
		pnameLabel.setBounds(220,20-18,90,40);
		pnameLabel.setForeground(Color.BLACK);
		f = new Font("Arial",Font.BOLD,12);
		pnameLabel.setFont(f);
		addproblemPanel.add(pnameLabel);
		
		
		
		JTextField pnameField = new JTextField();
		pnameField.setBounds(220,60-18,90,30);
		pnameField.setBackground(Color.WHITE);
		f = new Font("Arial",Font.BOLD,12);
		pnameField.setFont(f);
		addproblemPanel.add(pnameField);
		
		
		JLabel cb2Label = new JLabel("Difficulty");
		cb2Label.setBounds(320,20-18,90,40);
		cb2Label.setForeground(Color.BLACK);
		f = new Font("Arial",Font.BOLD,12);
		cb2Label.setFont(f);
		addproblemPanel.add(cb2Label);
		
		JComboBox cb2 = new JComboBox(new String[] {"Easy","medium","hard"});
		cb2.setBounds(320,60-18,90,30);
		addproblemPanel.add(cb2);
		
		
		inpuTextArea = new JTextArea("input data");
		f = new Font("Arial",Font.PLAIN,16);
		inpuTextArea.setFont(f);
		JScrollPane scrollinpuTextArea = new JScrollPane(inpuTextArea,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollinpuTextArea.setBounds(10,80,280,440-14);
		scrollinpuTextArea.setBackground(Color.WHITE);
		addproblemPanel.add(scrollinpuTextArea);
		
		outpuTextArea = new JTextArea("output data");
		f = new Font("Arial",Font.PLAIN,16);
		outpuTextArea.setFont(f);
		JScrollPane scrolloutpuTextArea = new JScrollPane(outpuTextArea,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrolloutpuTextArea.setBounds(300,80,280,440-14);
		scrolloutpuTextArea.setBackground(Color.WHITE);
		addproblemPanel.add(scrolloutpuTextArea);
		
		JButton addButton = new JButton("Add");
		addButton.setBounds(650,400,80,40);
		//addButton.setBounds(200,2,50,50);
		addButton.setCursor(cursor);
		addproblemPanel.add(addButton);
		
		
		
		addButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if(!probnoField2.getText().isEmpty()) {
					
					FileWriter writer1;
					FileWriter writer2;
					FileWriter writer3;
					// TODO Auto-generated method stub
					try {
						Files.createDirectories(Paths.get("data\\problem\\" +probnoField2.getText()));
						
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					try {
						writer1 = new FileWriter("data\\problem\\" +probnoField2.getText()+"\\"+probnoField2.getText()+"_in.txt");
						inpuTextArea.write(writer1);
						writer1.close();
						writer2 = new FileWriter("data\\problem\\" +probnoField2.getText()+"\\"+probnoField2.getText()+"_out.txt");
						outpuTextArea.write(writer2);
						writer2.close();
						writer3 = new FileWriter("data\\problem\\" +probnoField2.getText()+"\\"+probnoField2.getText()+"_link.txt");
						problinkField.write(writer3);
						writer3.close();
						String s1 = problinkField.getText().toString();
						String s2 = "data\\problem\\" +probnoField2.getText()+"\\"+probnoField2.getText()+".pdf";
						if(new File(s1).exists()) {
							fileCopy(new File(s1), new File(s2));
							//new pdfRead().openPdf(new File(s2));
							
						}else {
							jp("error pdf");
						}
//						try {
//							fileCopy(new File(s1), new File(s2));
//						} catch (Exception e) {
//							// TODO: handle exception
//							jp("error pdf");
//						}
						
						
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					String []value = new String[3];
					value[0]=probnoField2.getText().toString();
					value[1]=pnameField.getText().toString();
					value[2]=cb2.getSelectedItem().toString();
					//value[2]="ll";
					//value[3]="pp";
					Object rowObject[]=value;
//				      Object colmnObject[]=colmn;
					 ((DefaultTableModel) modelproblem).addRow(rowObject);
					//modelproblem.addRow1(rowObject);
					//modelproblem.addRow(value);
					//modelproblem.addRow(new Object[] {"ll","ll","ll","ll"});
//					try {
//						//new xlWorking().writeExcel((JTable)problemsetTable, new File("probtable5.xls"));
//						new xlWorking().writeExcel(problemsetTable, new File("tt.xls"));
//					} catch (WriteException e) {
//						System.out.println("cslling7");
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					} catch (IOException e) {
//						System.out.println("cslling8");
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
					
					try {
						new xlWorking().writeExcel(problemsetTable, new File("data\\table\\probtable.xls"));
					} catch (WriteException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				else {
					//modelproblem.addRow(new Object[] {"ll","ll","ll","ll"});
					jp("Add problem unsuccessful");
				}
				addproblemPanel.setVisible(false);
				tb.setVisible(true);
				
			}
		});
		
	}
	
	
	
	public void signout(String text,boolean temp) {
		if(temp) {
			signoutLabel.setText("hi, "+text);
			//System.out.println(text);
			signoutButton.setVisible(true);
			signoutLabel.setVisible(true);
		}
		else {
			signoutButton.setVisible(false);
			signoutLabel.setVisible(false);
			tb.setVisible(false);
			addproblemPanel.setVisible(false);
			signinPanel.setVisible(true);
			
			
		}
		
	}
	
	public void jp(String s) {
		JOptionPane.showMessageDialog(null, s);
	}
	
	public void fileCopy(File src,File dst) throws IOException {
		Files.copy(src.toPath(), dst.toPath());
	}
	
	
	
	
	
	
	
	//-------------class for action on usernamefield and passwordfield
	
	public class ActionOnText implements ActionListener{

		

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			
			if(e.getSource() == usernameField) {
				String s = usernameField.getText();
				if(s.isEmpty()) {
					JOptionPane.showMessageDialog(null, "please enter username");
				}
			}
			else if (e.getSource() == passwordField) {
				char ch[] = passwordField.getPassword();
				String s = String.valueOf(ch);
				System.out.println(passwordField.getPassword());
				if (s.isEmpty()) {
					JOptionPane.showMessageDialog(null, "please enter valid password");
				}
			}

		}
		

	}
	


	
	
	
	
	public void seticon() {
		icon = new ImageIcon(getClass().getResource("oj2.png"));
		this.setIconImage(icon.getImage());
	}

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		//-----------main frame cration---------------
		
		labelDemo frame = new labelDemo();
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		frame.setBounds(200, 80, 1000, 600);//1000,600
		frame.setTitle("Onsite Judge Developed By @Fahim61");
		
//		/*
//		 * fileWrite fWrite = new fileWrite("this is file4\ntt",
//		 * "src/fileWriting/file1.txt"); fWrite.append();
		 
		
//		CheckingSignIn checkingSignIn = new CheckingSignIn("src/fileWriting/usernamelist.txt","f0", "12");
//		checkingSignIn.ismatch();
		
//		try {
//			String[] cmd1 = {"/bin/sh", "-c", "diff op.txt a.txt"};
//			Process proc = Runtime.getRuntime().exec(cmd1);
//			proc.waitFor();
//			int j = proc.exitValue();
//			if(j==0)
//				System.out.println("ac");
//			else
//				System.out.println("WA");
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		//Path p1 = Paths.get("op.txt");
//		File file1 = new File("op.txt");
//		File file2 = new File("a.txt");
//		//FileU
//		//file1.equals)
//		System.out.println(file1.equals(file2));
		
//		JavaChecking javaChecking1 = new JavaChecking("Problem4A"+"."+"java", "Codeforces-4A");
//		System.out.println(javaChecking1.compilejava());
		
		
	}

}
