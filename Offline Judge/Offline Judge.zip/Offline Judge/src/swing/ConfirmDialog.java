package swing;

import javax.swing.JOptionPane;

public class ConfirmDialog {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int choice = JOptionPane.showConfirmDialog(null,"Do u want to quit now?","Confirm box",JOptionPane.YES_NO_OPTION);
		if(choice == JOptionPane.YES_OPTION) {
			JOptionPane.showMessageDialog(null,"yes pressed");
		}
		else {
			JOptionPane.showMessageDialog(null,"no pressed");
		}
	}

}
