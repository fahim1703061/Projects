package swing;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import fileWriting.fileWrite;

public class SignUpframe extends JFrame{
	

	private JTextField usernameField,nameField;
	private JPasswordField passwordField,confirmPasswordField;
	private Container c;
	private Font f;
	private JButton submitButton;
	private boolean submitButtonPressed;
	
	private JLabel nameLabel,userLabel,passLabel,confirmpasslLabel;
	
	SignUpframe(){
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100,50,300,600);
		setTitle("sign up");
		setSubmitButtonPressed(true);
		setField();
		
	}
	public boolean isSubmitButtonPressed() {
		return submitButtonPressed;
	}
	public void setSubmitButtonPressed(boolean submitButtonPressed) {
		this.submitButtonPressed = submitButtonPressed;
	}
	public void setField() {
		c=getContentPane();
		c.setLayout(null);
		c.setBackground(Color.DARK_GRAY);
		
		
		//---------adding field-----------
		
		
		f = new Font("Arial",Font.BOLD,16);
		
		nameLabel = new JLabel("Enter name:");
		nameLabel.setBounds(10,10,150,30);
		nameLabel.setFont(f);
		nameLabel.setForeground(Color.WHITE);

		c.add(nameLabel);
		
		nameField = new JTextField();
		nameField.setBounds(10,42,150,30);
		f = new Font("Arial",Font.BOLD,16);
		nameField.setFont(f);
		c.add(nameField);
		
		
		f = new Font("Arial",Font.BOLD,16);
		
		userLabel = new JLabel("Enter username:");
		userLabel.setBounds(10,74,150,30);
		userLabel.setFont(f);
		userLabel.setForeground(Color.WHITE);

		c.add(userLabel);
		
		usernameField = new JTextField();
		usernameField.setBounds(10,106,150,30);
		f = new Font("Arial",Font.BOLD,16);
		usernameField.setFont(f);
		c.add(usernameField);
		
		f = new Font("Arial",Font.BOLD,16);
		
		passLabel = new JLabel("Enter password:");
		passLabel.setBounds(10,138,150,30);
		passLabel.setFont(f);
		passLabel.setForeground(Color.WHITE);
		c.add(passLabel);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(10,170,150,30);
		f = new Font("Arial",Font.BOLD,16);
		passwordField.setFont(f);
		c.add(passwordField);
		
		f = new Font("Arial",Font.BOLD,16);
		
		confirmpasslLabel = new JLabel("Enter confirm password:");
		confirmpasslLabel.setBounds(10,202,190,30);
		confirmpasslLabel.setFont(f);
		confirmpasslLabel.setForeground(Color.WHITE);
		c.add(confirmpasslLabel);
		
		confirmPasswordField = new JPasswordField();
		confirmPasswordField.setBounds(10,234,150,30);
		f = new Font("Arial",Font.BOLD,16);
		confirmPasswordField.setFont(f);
		c.add(confirmPasswordField);
		
		submitButton = new JButton("Submit");
		submitButton.setBounds(10,280,100,50);
		c.add(submitButton);
		
		submitButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				setSubmitButtonPressed(true);
				//System.out.println(submitButtonPressed);
				fileWrite fWrite = new fileWrite("", "data/account/"+usernameField.getText()+".txt");
				fileWrite fWrite2 = new fileWrite("", "data/useridlist/usernamelist.txt");
				
				String string = new String();
				string = usernameField.getText();
				usernameField.setText("");
				fWrite.append(string);
				fWrite2.append(string);
				
				string = nameField.getText();
				nameField.setText("");
				fWrite.append(string);
				
				string = String.valueOf(passwordField.getPassword());
				passwordField.setText("");
				confirmPasswordField.setText("");
				fWrite.append(string);
				
				
				
				JOptionPane.showMessageDialog(null, "Successfully submitted");
				
			}
		});
		
	}
	
}
