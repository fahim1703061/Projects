package swing;

import java.awt.Color;
import java.awt.Container;

import javax.swing.ImageIcon;
import javax.swing.JFrame;

public class FrameWithIcon extends JFrame{
	
	private ImageIcon icon;
	private Container c;
	
	public FrameWithIcon() {
		// TODO Auto-generated constructor stub
		//System.out.println(getClass());// get class()This method returns the
									  //object of type 'Class' that represents 
									 //	the runtime class of the object.
		/*getResource() is method under a Class class which is invoked through a Class
		 * object and This method returns a URL object or null if no resource with this
		 *  name is found.
		 */
		seticon();
		useContainer();
		
		
	}
	public void useContainer() {
		// TODO Auto-generated method stub
		c=getContentPane();
		
		c.setBackground(Color.WHITE);
	}
	public void seticon() {
		icon = new ImageIcon(getClass().getResource("oj2.png"));
		this.setIconImage(icon.getImage());
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//-----------main frame cration---------------
		
		FrameWithIcon frame = new FrameWithIcon();
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		frame.setBounds(200, 80, 1000, 600);
		frame.setTitle("Onsite Judge Developed By @Fahim61");
		

	}

}
