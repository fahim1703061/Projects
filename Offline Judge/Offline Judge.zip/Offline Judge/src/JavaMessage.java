import javax.swing.JOptionPane;

import org.omg.PortableServer.POAPackage.WrongAdapter;
public class JavaMessage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		//JOptionPane.showMessageDialog(null, "wrong password");
		//JOptionPane.showMessageDialog(null,"wrong password","Alert",JOptionPane.ERROR_MESSAGE);
		String name = JOptionPane.showInputDialog("What is your name?");
		//JOptionPane.showMessageDialog(null, name+" is your name");
		String nullString = new String("ll");
		System.out.println(name);
		System.out.println("tt");
		if(name.equals("null")==true) {
			JOptionPane.showMessageDialog(null, name+" is your name");
		}
		
		System.out.println("tt");
	}

}
